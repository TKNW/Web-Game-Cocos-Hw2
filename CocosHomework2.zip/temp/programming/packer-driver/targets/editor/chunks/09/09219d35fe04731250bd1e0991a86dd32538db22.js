System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, Layout, _decorator, Component, Button, PageView, UITransform, _dec, _dec2, _dec3, _class, _class2, _descriptor, _descriptor2, _crd, ccclass, property, requireComponent, LoopPageView;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'proposal-class-properties is enabled and runs after the decorators transform.'); }

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      Layout = _cc.Layout;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Button = _cc.Button;
      PageView = _cc.PageView;
      UITransform = _cc.UITransform;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "1fcb9Z0GA9MLq0hSmTKIB0P", "LoopPageView", undefined);

      __checkObsolete__(['Layout']);

      __checkObsolete__(['_decorator', 'Component', 'Button', 'PageView', 'Node', 'UITransform']);

      ({
        ccclass,
        property,
        requireComponent
      } = _decorator);

      _export("LoopPageView", LoopPageView = (_dec = requireComponent(PageView), _dec2 = property({
        type: Button
      }), _dec3 = property({
        type: Button
      }), ccclass(_class = _dec(_class = (_class2 = class LoopPageView extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "prevButton", _descriptor, this);

          _initializerDefineProperty(this, "nextButton", _descriptor2, this);

          this.pageView = null;
          this.lastContentPosX = null;
        }

        onLoad() {
          this.pageView = this.getComponent(PageView);
          this.prevButton.node.on(Button.EventType.CLICK, this.onPrevButtonClick, this);
          this.nextButton.node.on(Button.EventType.CLICK, this.onNextButtonClick, this);
          this.pageView.node.on(PageView.EventType.PAGE_TURNING, this.onPageTurning, this);
        }

        start() {
          // this.pageView.scrollToPage(1);
          this.pageView.setCurrentPageIndex(1);
          this.lastContentPosX = this.pageView.content.position.x;
          const centerPos = this.pageView.getPages().length / 2 * this.pageView.getPages()[0].getComponent(UITransform).width;
          console.log(`center: ${centerPos}`);
        }

        onPrevButtonClick() {
          const currentPage = this.pageView.getCurrentPageIndex();
          const totalPages = this.pageView.getPages().length;

          if (currentPage === 0) {
            this.pageView.scrollToPage(totalPages - 1);
          } else {
            this.pageView.scrollToPage(currentPage - 1);
          }
        }

        onNextButtonClick() {
          const currentPage = this.pageView.getCurrentPageIndex();
          const totalPages = this.pageView.getPages().length;

          if (currentPage === totalPages - 1) {
            this.pageView.scrollToPage(0);
          } else {
            this.pageView.scrollToPage(currentPage + 1);
          }
        }

        onPageTurning() {
          const currentContentPosX = this.pageView.content.position.x;
          this.resetContentPosition(this.lastContentPosX - currentContentPosX);
          this.lastContentPosX = this.pageView.content.position.x;
        }

        resetContentPosition(offset) {
          const pages = this.pageView.getPages();
          pages.forEach(element => {
            let contentPosX = this.pageView.content.position.x + element.position.x;
            const bound = Math.floor(this.pageView.getPages().length / 2 * this.pageView.getPages()[0].getComponent(UITransform).width); //console.log(`${element.name} : ${contentPosX}`);

            if (contentPosX < -bound) {
              console.log(`left ${element.name}`);

              const index = this.pageView._pages.indexOf(element);

              if (index >= 0) {
                this.pageView._pages.splice(index, 1);
              }

              element.parent = null; // this.pageView.removePage(element);

              this.pageView.addPage(element);
              this.pageView.scrollToPage(1, 0.001);

              this.pageView._updatePageView();

              this.pageView.getComponentInChildren(Layout).updateLayout(true);
            } else if (contentPosX > bound) {
              console.log(`right ${element.name}`);

              const index = this.pageView._pages.indexOf(element);

              if (index >= 0) {
                this.pageView._pages.splice(index, 1);
              }

              element.parent = null; // this.pageView.removePage(element);

              this.pageView.insertPage(element, 0);
              this.pageView.scrollToPage(1, 0.001);

              this.pageView._updatePageView();

              this.pageView.getComponentInChildren(Layout).updateLayout(true);
            }
          });

          if (offset > 0) {
            console.log(`right, ${this.pageView.curPageIdx}`);
          } else {
            console.log(`left, ${this.pageView.curPageIdx}`);
          }
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "prevButton", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "nextButton", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      })), _class2)) || _class) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=09219d35fe04731250bd1e0991a86dd32538db22.js.map