System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, Button, Component, EditBox, _decorator, NumberFormatter, RangeSlider, _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _crd, ccclass, requireComponent, property, RunningMeter;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'proposal-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfNumberFormatter(extras) {
    _reporterNs.report("NumberFormatter", "./NumberFormatter", _context.meta, extras);
  }

  function _reportPossibleCrUseOfRangeSlider(extras) {
    _reporterNs.report("RangeSlider", "./RangeSlider", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      Button = _cc.Button;
      Component = _cc.Component;
      EditBox = _cc.EditBox;
      _decorator = _cc._decorator;
    }, function (_unresolved_2) {
      NumberFormatter = _unresolved_2.default;
    }, function (_unresolved_3) {
      RangeSlider = _unresolved_3.default;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "8a217/lbKZFRLqoZsqs/Wnk", "RunningMeter", undefined);

      __checkObsolete__(['Button', 'CCFloat', 'Component', 'EditBox', '_decorator']);

      ({
        ccclass,
        requireComponent,
        property
      } = _decorator);

      _export("default", RunningMeter = (_dec = requireComponent(_crd && NumberFormatter === void 0 ? (_reportPossibleCrUseOfNumberFormatter({
        error: Error()
      }), NumberFormatter) : NumberFormatter), _dec2 = property(_crd && RangeSlider === void 0 ? (_reportPossibleCrUseOfRangeSlider({
        error: Error()
      }), RangeSlider) : RangeSlider), _dec3 = property(EditBox), _dec4 = property(EditBox), _dec5 = property(Button), _dec6 = property(Button), ccclass(_class = _dec(_class = (_class2 = class RunningMeter extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "speedSlider", _descriptor, this);

          _initializerDefineProperty(this, "startValueEditBox", _descriptor2, this);

          _initializerDefineProperty(this, "targetValueEditBox", _descriptor3, this);

          _initializerDefineProperty(this, "startButton", _descriptor4, this);

          _initializerDefineProperty(this, "stopButton", _descriptor5, this);

          this.text = null;
          this.targetValue = 0;
          this.speed = 20;
          this._promise = null;
          this._promiseResolve = null;
        }

        onLoad() {
          this.text = this.getComponent(_crd && NumberFormatter === void 0 ? (_reportPossibleCrUseOfNumberFormatter({
            error: Error()
          }), NumberFormatter) : NumberFormatter);
          this.startButton.node.on(Button.EventType.CLICK, this.startRunning, this);
          this.stopButton.node.on(Button.EventType.CLICK, this.forceStop, this);
        }

        update(deltaTime) {
          if (this.text.value !== this.targetValue) {
            const addValue = deltaTime * this.speed;
            this.text.value += addValue;

            if (this.text.value >= this.targetValue) {
              var _this$_promiseResolve;

              this.text.value = this.targetValue;
              (_this$_promiseResolve = this._promiseResolve) == null ? void 0 : _this$_promiseResolve.call(this);
              this._promiseResolve = null;
            }
          }
        }

        get promise() {
          return this._promise;
        }

        get isRunning() {
          return !!this._promiseResolve;
        }

        get value() {
          return this.text.value;
        }

        set value(value) {
          // 直接設定值之前，先將原本還在進行的數字跳動停止
          this.targetValue = value;
          this.text.value = value;
        }

        run(targetValue, originValue) {
          this.targetValue = targetValue;

          if (originValue !== undefined) {
            this.text.value = originValue;
          }

          this._promise = new Promise(resolve => {
            this._promiseResolve = resolve;
          });
          return this._promise;
        }

        async forceStop() {
          var _this$_promiseResolve2;

          this.text.value = this.targetValue;
          (_this$_promiseResolve2 = this._promiseResolve) == null ? void 0 : _this$_promiseResolve2.call(this);
          this._promiseResolve = null;
        }

        startRunning() {
          const startValue = +this.startValueEditBox.string;
          const endValue = +this.targetValueEditBox.string;

          if (isNaN(startValue) || isNaN(endValue)) {
            return;
          }

          this.speed = this.speedSlider.value;
          this.run(endValue, startValue);
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "speedSlider", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "startValueEditBox", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "targetValueEditBox", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "startButton", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "stopButton", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=245338f6fc27964edf3a89ca4f0b98d9ec410d97.js.map