System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, Sprite, log, Node, Animation, UIOpacity, tween, _dec, _dec2, _dec3, _class, _class2, _descriptor, _descriptor2, _descriptor3, _crd, EIGHT_SIDED, QUICK_EXPLODE, NORMAL_EXPLODE, ccclass, property, Explode;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'proposal-class-properties is enabled and runs after the decorators transform.'); }

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Sprite = _cc.Sprite;
      log = _cc.log;
      Node = _cc.Node;
      Animation = _cc.Animation;
      UIOpacity = _cc.UIOpacity;
      tween = _cc.tween;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "c5857pRrTdN/IKtl7ZhaQk0", "Explode", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Sprite', 'AnimationState', 'SpriteFrame', 'log', 'AnimationClip', 'Node', 'Animation', 'Vec3', 'UIOpacity', 'tween']);

      _export("EIGHT_SIDED", EIGHT_SIDED = {
        CENTER: -1,
        TOP: 0,
        RIGHT: 1,
        DOWN: 2,
        LEFT: 3,
        TOP_LEFT: 4,
        TOP_RIGHT: 5,
        DOWN_LEFT: 6,
        DOWN_RIGHT: 7
      });

      QUICK_EXPLODE = ['GemEffect_H'];
      NORMAL_EXPLODE = ['GemEffect'];
      ({
        ccclass,
        property
      } = _decorator);

      _export("default", Explode = (_dec = property({
        type: Node,
        tooltip: '寶石節點'
      }), _dec2 = property({
        type: Sprite,
        tooltip: '寶石顯示的Sprite'
      }), _dec3 = property({
        type: Sprite,
        tooltip: '背景寶石顯示的Sprite'
      }), ccclass(_class = (_class2 = class Explode extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "m_gemNodes", _descriptor, this);

          _initializerDefineProperty(this, "m_gemSprites", _descriptor2, this);

          _initializerDefineProperty(this, "m_gemBgSprites", _descriptor3, this);

          this.m_symbolNumber = 0;
          this.m_pos = null;
        }

        set Position(v) {
          this.m_pos = v;
        }

        get Position() {
          return this.m_pos;
        }

        Init() {
          for (let i = 0; i < this.m_gemNodes.length; i++) {
            let anim = this.m_gemNodes[i].getComponent(Animation);

            if (Object.keys(anim['_nameToState']).length == 0) {
              // 先檢查是否為空
              anim.onLoad(); // 再手動初始化。不可重複呼叫，否則動畫播放狀態將會被重置。
            }

            anim.play(QUICK_EXPLODE[0]);
            let animState = anim.getState(QUICK_EXPLODE[0]); // 362 getState

            animState.stop();
          }
        }

        SetSymbol(symbol, spriteFrame, bgSpriteFrame) {
          this.m_gemNodes.forEach((value, index, array) => {
            value.active = false;
          });

          if (!this.m_gemNodes[symbol]) {
            log('symbol11111', symbol);
          }

          this.m_gemNodes[symbol].active = true;
          this.m_gemSprites[symbol].spriteFrame = spriteFrame;
          this.m_gemSprites[symbol].node.active = true; // this.m_gemBgSprites[symbol].spriteFrame = bgSpriteFrame;

          this.m_gemBgSprites[symbol].node.getComponent(UIOpacity).opacity = 0;
          this.m_gemBgSprites[symbol].node.active = true;
          this.m_symbolNumber = symbol;
        }

        GetNormalAnimTime() {
          let animClips = this.m_gemNodes[this.m_symbolNumber].getComponent(Animation).clips;

          for (let i = 0; i < animClips.length; i++) {
            if (animClips[i].name === NORMAL_EXPLODE[0]) {
              return animClips[i].duration;
            }
          }

          return 0;
        }

        SetActive(nodes, active) {
          for (let i = 0; i < nodes.length; i++) {
            nodes[i].active = active;
          }
        }

        ShowExplode(isHardStop, endCb) {
          let animName = isHardStop ? QUICK_EXPLODE[0] : NORMAL_EXPLODE[0];
          let anim = this.m_gemNodes[this.m_symbolNumber].getComponent(Animation);
          anim.play(animName);
          let animState = anim.getState(animName);
          console.log(animName, animState, this.m_gemNodes[this.m_symbolNumber].active);
          tween(this.node).delay(animState.duration).call(() => {
            if (endCb) {
              endCb();
            }
          }).start();
          return animState.duration;
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "m_gemNodes", [_dec], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return [];
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "m_gemSprites", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return [];
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "m_gemBgSprites", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return [];
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=213c6575b31dc15814f8608595fb9f8d2fb83bf3.js.map