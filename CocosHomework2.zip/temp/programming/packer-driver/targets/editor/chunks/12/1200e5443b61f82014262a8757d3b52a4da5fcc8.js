System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, Sprite, _dec, _class, _crd, ccclass, requireComponent, RadialProgress;

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Sprite = _cc.Sprite;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "fa693qsqY1ADqLTUEU39X4a", "RadialProgress", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Sprite']);

      ({
        ccclass,
        requireComponent
      } = _decorator);

      _export("RadialProgress", RadialProgress = (_dec = requireComponent(Sprite), ccclass(_class = _dec(_class = class RadialProgress extends Component {
        constructor(...args) {
          super(...args);
          this.sprite = null;
        }

        onLoad() {
          this.sprite = this.getComponent(Sprite);
        }

        get progress() {
          return Math.min(0, Math.max(0, this.sprite.fillRange * -1));
        }

        set progress(value) {
          if (value > 1) {
            value = 1;
          } else if (value < 0) {
            value = 0;
          }

          this.sprite.fillRange = -value;
        }

      }) || _class) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=1200e5443b61f82014262a8757d3b52a4da5fcc8.js.map