System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, NodePool, v3, tween, Node, instantiate, Prefab, _decorator, Component, Button, _dec, _dec2, _dec3, _dec4, _dec5, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _crd, ccclass, property, SlotReels;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'proposal-class-properties is enabled and runs after the decorators transform.'); }

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      NodePool = _cc.NodePool;
      v3 = _cc.v3;
      tween = _cc.tween;
      Node = _cc.Node;
      instantiate = _cc.instantiate;
      Prefab = _cc.Prefab;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Button = _cc.Button;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "34f47PvhNFDv4sid0yBwY5B", "SlotReels", undefined);

      __checkObsolete__(['NodePool']);

      __checkObsolete__(['v3']);

      __checkObsolete__(['tween']);

      __checkObsolete__(['Node']);

      __checkObsolete__(['instantiate']);

      __checkObsolete__(['Prefab']);

      __checkObsolete__(['_decorator', 'Component', 'Button']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("SlotReels", SlotReels = (_dec = property({
        type: Button
      }), _dec2 = property({
        type: [Node]
      }), _dec3 = property({
        type: Prefab
      }), _dec4 = property({
        type: Prefab
      }), _dec5 = property({
        type: Prefab
      }), ccclass(_class = (_class2 = class SlotReels extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "spinButton", _descriptor, this);

          _initializerDefineProperty(this, "reels", _descriptor2, this);

          _initializerDefineProperty(this, "symbolDefaultPrefab", _descriptor3, this);

          _initializerDefineProperty(this, "symbolEffectPrefab", _descriptor4, this);

          _initializerDefineProperty(this, "explodeEffectPrefab", _descriptor5, this);

          this.m_symbol = [];
          this.symbolDefaultPool = new NodePool();
          this.symbolEffectPool = new NodePool();
          this.explodeEffectPool = new NodePool();
          this.realCount = 5;
          this.symbolCountPerReel = 4;
          this.symbolPositions = [v3(0, 187.5), v3(0, 62.5), v3(0, -62.5), v3(0, -187.5)];
        }

        onLoad() {
          // 初始化預設盤面
          this.m_symbol = [];
          this.reels.forEach(reel => {
            const reelSymbols = [...reel.children];
            this.m_symbol.push(reelSymbols);
          });
          this.spinButton.node.on(Button.EventType.CLICK, this.startSpin, this);
        }

        startSpin() {
          for (let i = 0; i < this.realCount; i++) {
            for (let j = 0; j < this.symbolCountPerReel; j++) {
              tween(this.m_symbol[i][j]).by(0.5, {
                position: v3(0, -485)
              }).start();
            }
          }
        } // 取得一個靜態Symbol實例


        getNewDefaultSymbol() {
          var _this$symbolDefaultPo;

          return (_this$symbolDefaultPo = this.symbolDefaultPool.get()) != null ? _this$symbolDefaultPo : (() => {
            const node = instantiate(this.symbolDefaultPrefab);
            node.on('recyle', () => {
              this.symbolDefaultPool.put(node);
            });
          })();
        } // 取得一個Symbol動畫實例


        getNewSymbolEffect() {
          var _this$symbolEffectPoo;

          return (_this$symbolEffectPoo = this.symbolEffectPool.get()) != null ? _this$symbolEffectPoo : (() => {
            const node = instantiate(this.symbolEffectPrefab);
            node.on('recyle', () => {
              this.symbolEffectPool.put(node);
            });
          })();
        } // 取得一個消除動畫實例


        getNewExplodeEffect() {
          var _this$explodeEffectPo;

          return (_this$explodeEffectPo = this.explodeEffectPool.get()) != null ? _this$explodeEffectPo : (() => {
            const node = instantiate(this.explodeEffectPrefab);
            node.on('recyle', () => {
              this.explodeEffectPool.put(node);
            });
          })();
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "spinButton", [_dec], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "reels", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return [];
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "symbolDefaultPrefab", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "symbolEffectPrefab", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "explodeEffectPrefab", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=0590dddc29d87132fcf96193b09f765703c20e25.js.map