System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2", "__unresolved_3"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, Button, Prefab, instantiate, Node, tween, v3, NodePool, Animation, log, Explode, Delay, SlotSymbol, _dec, _dec2, _dec3, _dec4, _dec5, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _crd, ccclass, property, SlotReels;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'proposal-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfExplode(extras) {
    _reporterNs.report("Explode", "../game/Script/Explode", _context.meta, extras);
  }

  function _reportPossibleCrUseOfDelay(extras) {
    _reporterNs.report("Delay", "./Delay", _context.meta, extras);
  }

  function _reportPossibleCrUseOfSlotSymbol(extras) {
    _reporterNs.report("SlotSymbol", "./SlotSymbol", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Button = _cc.Button;
      Prefab = _cc.Prefab;
      instantiate = _cc.instantiate;
      Node = _cc.Node;
      tween = _cc.tween;
      v3 = _cc.v3;
      NodePool = _cc.NodePool;
      Animation = _cc.Animation;
      log = _cc.log;
    }, function (_unresolved_2) {
      Explode = _unresolved_2.default;
    }, function (_unresolved_3) {
      Delay = _unresolved_3.Delay;
    }, function (_unresolved_4) {
      SlotSymbol = _unresolved_4.SlotSymbol;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "34f47PvhNFDv4sid0yBwY5B", "SlotReels", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Button', 'Prefab', 'instantiate', 'Node', 'tween', 'v3', 'NodePool', 'Animation', 'log']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("SlotReels", SlotReels = (_dec = property({
        type: Button
      }), _dec2 = property({
        type: [Node]
      }), _dec3 = property({
        type: Prefab
      }), _dec4 = property({
        type: Prefab
      }), _dec5 = property({
        type: Prefab
      }), ccclass(_class = (_class2 = class SlotReels extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "spinButton", _descriptor, this);

          _initializerDefineProperty(this, "reels", _descriptor2, this);

          _initializerDefineProperty(this, "symbolDefaultPrefab", _descriptor3, this);

          _initializerDefineProperty(this, "symbolEffectPrefab", _descriptor4, this);

          _initializerDefineProperty(this, "explodeEffectPrefab", _descriptor5, this);

          this.symbolDefaultPool = new NodePool();
          this.symbolEffectPool = new NodePool();
          this.explodeEffectPool = new NodePool();
          this.realCount = 5;
          this.symbolCountPerReel = 4;
          this.symbolPositions = [v3(0, 187.5), v3(0, 62.5), v3(0, -62.5), v3(0, -187.5)];
          this.m_symbols = [];
          this.onSpinState = false;
        }

        onLoad() {
          // 初始化預設盤面
          this.m_symbols = [];
          this.reels.forEach(reel => {
            const reelSymbols = [];

            for (let j = 0; j < this.symbolCountPerReel; j++) {
              const node = this.getNewDefaultSymbol();
              node.parent = reel;
              node.position = this.symbolPositions[j];
              reelSymbols.push(node);
            }

            this.m_symbols.push(reelSymbols);
          });
          this.spinButton.node.on(Button.EventType.CLICK, this.gameFlow, this);
        } // 單輪遊戲流程，按下按鈕時執行


        async gameFlow() {
          // 避免反覆點擊按鈕
          if (this.onSpinState) {
            log('return');
            return;
          }

          this.onSpinState = true;
          await this.startSpin();
          await (_crd && Delay === void 0 ? (_reportPossibleCrUseOfDelay({
            error: Error()
          }), Delay) : Delay).resolve(100);
          await this.showNewPlate();
          await (_crd && Delay === void 0 ? (_reportPossibleCrUseOfDelay({
            error: Error()
          }), Delay) : Delay).resolve(100);
          let hasExplode = await this.explode();

          while (hasExplode) {
            // 暫時做法，我目前沒招= =
            await (_crd && Delay === void 0 ? (_reportPossibleCrUseOfDelay({
              error: Error()
            }), Delay) : Delay).resolve(1000);
            log('Toofast?');
            await this.tileMatching();
            await this.patchUp();
            await (_crd && Delay === void 0 ? (_reportPossibleCrUseOfDelay({
              error: Error()
            }), Delay) : Delay).resolve(100); // hasExplode = await this.explode();

            hasExplode = false;
          }

          this.onSpinState = false;
        }

        async generateNewSymbol() {
          for (let i = 0; i < this.m_symbols.length; i++) {
            for (let j = 0; j < this.m_symbols[i].length; j++) {
              const node = this.getNewDefaultSymbol();
              node.parent = this.reels[i];
              node.position = this.symbolPositions[j];
              node.position = node.position.add(v3(0, 485));
              this.m_symbols[i][j] = node;
            }
          }
        } // 表演－將所有符號掉落離開盤面, 此 function 將於表演結束後 return


        async startSpin() {
          const promiseArray = [];

          for (let i = 0; i < this.m_symbols.length; i++) {
            for (let j = 0; j < this.m_symbols[i].length; j++) {
              if (this.m_symbols[i][j]) {
                promiseArray.push(new Promise(resolve => {
                  tween(this.m_symbols[i][j]).by(0.5, {
                    position: v3(0, -485)
                  }).call(() => {
                    this.m_symbols[i][j].emit('recycle');
                    this.m_symbols[i][j] = null;
                    resolve();
                  }).start();
                }));
              }
            }
          }

          return Promise.all(promiseArray);
        } // TODO: 表演－掉第一個盤面(完整盤面)的新符號下來, 此 function 將於表演結束後 return


        async showNewPlate() {
          const promiseArray = [];
          this.generateNewSymbol();

          for (let i = 0; i < this.m_symbols.length; i++) {
            for (let j = 0; j < this.m_symbols[i].length; j++) {
              if (this.m_symbols[i][j]) {
                promiseArray.push(new Promise(resolve => {
                  tween(this.m_symbols[i][j]).by(0.5, {
                    position: v3(0, -485)
                  }).call(() => {
                    resolve();
                  }).start();
                }));
              }
            }
          }

          return Promise.all(promiseArray);
        } // TODO: 表演－消除當前盤面應被消除的符號, 此 function 將於表演結束後 return true; 若無消除表演的話則 return false;


        async explode() {
          const explodeNode = this.needExplodeSymbolTypes;

          if (explodeNode.length !== 0) {
            const promiseArray = [];

            for (let k = 0; k < explodeNode.length; k++) {
              for (let i = 0; i < this.m_symbols.length; i++) {
                for (let j = 0; j < this.m_symbols[i].length; j++) {
                  if (this.m_symbols[i][j] && this.m_symbols[i][j].getComponent(_crd && SlotSymbol === void 0 ? (_reportPossibleCrUseOfSlotSymbol({
                    error: Error()
                  }), SlotSymbol) : SlotSymbol).type === explodeNode[k]) {
                    promiseArray.push(new Promise(resolve => {
                      this.playSymbolAnimation(this.m_symbols[i][j].getComponent(_crd && SlotSymbol === void 0 ? (_reportPossibleCrUseOfSlotSymbol({
                        error: Error()
                      }), SlotSymbol) : SlotSymbol));
                      this.m_symbols[i][j].emit('recycle');
                      this.m_symbols[i][j] = null;
                      resolve();
                    }));
                  }
                }
              }
            }

            await Promise.all(promiseArray).then(() => log('promise return'));
            return true;
          }

          return false;
        } // TODO: 表演－原有(未被消除)的符號往下掉, 此 function 將於表演結束後 return


        async tileMatching() {
          const promiseArray = [];
          /* for (let i = 0; i < this.m_symbols.length; i++) {
              for (let j = this.m_symbols[i].length - 1; j >= 0; j--) {
                  if (this.m_symbols[i][j] === null) {
                      for (let k = j - 1; k >= 0; --k) {
                          if (this.m_symbols[i][k] === null) {
                              continue;
                          }
                          const movePosition = this.symbolPositions[j].subtract(this.symbolPositions[k]);
                          promiseArray.push(
                              new Promise<void>((resolve) => {
                                  tween(this.m_symbols[i][k])
                                      .by(0.5, { position: movePosition })
                                      .call(() => {
                                          this.m_symbols[i][j] = this.m_symbols[i][k];
                                          this.m_symbols[i][k] = null;
                                          resolve();
                                      })
                                      .start();
                              }),
                          );
                          break;
                      }
                  }
              }
          }
          log(promiseArray.length); */

          return Promise.all(promiseArray);
        } // TODO: 表演－將盤面補滿符號, 此 function 將於表演結束後 return


        async patchUp() {} // 表演－單個Symbol消除動畫 (包含 SymbolEffect 及 ExplodeEffect), 此 function 將於表演結束後 return


        async playSymbolAnimation(symbol) {
          const symbolEffect = this.getNewSymbolEffect();
          const explodeEffect = this.getNewExplodeEffect();
          symbolEffect.parent = symbol.node.parent;
          explodeEffect.parent = symbol.node.parent;
          symbolEffect.position = symbol.node.position;
          explodeEffect.position = symbol.node.position;
          const explode = symbolEffect.getComponent(_crd && Explode === void 0 ? (_reportPossibleCrUseOfExplode({
            error: Error()
          }), Explode) : Explode);
          explode.Init();
          explodeEffect.getComponent(Animation).play();
          await new Promise(resolve => {
            explode.SetSymbol(symbol.type, symbol.sprite.spriteFrame);
            explode.ShowExplode(false, () => {
              resolve();
              symbolEffect.emit('recycle');
              explodeEffect.emit('recycle');
            });
          });
        } // 取得一個靜態Symbol實例


        getNewDefaultSymbol() {
          var _this$symbolDefaultPo;

          const newNode = (_this$symbolDefaultPo = this.symbolDefaultPool.get()) != null ? _this$symbolDefaultPo : (() => {
            const node = instantiate(this.symbolDefaultPrefab);
            node.on('recycle', () => {
              node.parent = null;
              node.active = false;
              this.symbolDefaultPool.put(node);
            });
            return node;
          })(); // 隨機更新符號型別

          newNode.getComponent(_crd && SlotSymbol === void 0 ? (_reportPossibleCrUseOfSlotSymbol({
            error: Error()
          }), SlotSymbol) : SlotSymbol).randomType();
          newNode.active = true;
          return newNode;
        } // 取得一個Symbol動畫實例


        getNewSymbolEffect() {
          var _this$symbolEffectPoo;

          return (_this$symbolEffectPoo = this.symbolEffectPool.get()) != null ? _this$symbolEffectPoo : (() => {
            const node = instantiate(this.symbolEffectPrefab);
            node.on('recycle', () => {
              node.parent = null;
              this.symbolEffectPool.put(node);
            });
            return node;
          })();
        } // 取得一個消除動畫實例


        getNewExplodeEffect() {
          var _this$explodeEffectPo;

          return (_this$explodeEffectPo = this.explodeEffectPool.get()) != null ? _this$explodeEffectPo : (() => {
            const node = instantiate(this.explodeEffectPrefab);
            node.on('recycle', () => {
              node.parent = null;
              this.explodeEffectPool.put(node);
            });
            return node;
          })();
        } // 計算當前盤面應被消除的符號種類


        get needExplodeSymbolTypes() {
          const symbolTypes = {};
          this.m_symbols.forEach(reel => {
            reel.forEach(symbolNode => {
              const symbol = symbolNode.getComponent(_crd && SlotSymbol === void 0 ? (_reportPossibleCrUseOfSlotSymbol({
                error: Error()
              }), SlotSymbol) : SlotSymbol);

              if (!symbolTypes[symbol.type]) {
                symbolTypes[symbol.type] = 0;
              }

              symbolTypes[symbol.type]++;
            });
          });
          const pairs = Object.entries(symbolTypes); // 相同的符號達到5個以上時，應該要消除

          const result = pairs.filter(pair => pair[1] > 5);
          return result.map(pair => +pair[0]);
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "spinButton", [_dec], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "reels", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return [];
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "symbolDefaultPrefab", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "symbolEffectPrefab", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "explodeEffectPrefab", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=4745646e42e7bfbe75f29acb9acf075e86b3692f.js.map