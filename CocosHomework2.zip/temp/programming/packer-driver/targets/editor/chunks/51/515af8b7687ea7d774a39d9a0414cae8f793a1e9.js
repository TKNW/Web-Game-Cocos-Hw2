System.register(["__unresolved_0", "cc", "__unresolved_1"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, EditBox, Button, Label, RadialProgress, _dec, _dec2, _dec3, _dec4, _dec5, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _crd, ccclass, property, Timer;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'proposal-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfRadialProgress(extras) {
    _reporterNs.report("RadialProgress", "./RadialProgress", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      EditBox = _cc.EditBox;
      Button = _cc.Button;
      Label = _cc.Label;
    }, function (_unresolved_2) {
      RadialProgress = _unresolved_2.RadialProgress;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "f125bmVF7dH+o+Wm6ommjbm", "Timer", undefined);

      __checkObsolete__(['_decorator', 'Component', 'EditBox', 'Button', 'Label']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("Timer", Timer = (_dec = property({
        type: EditBox,
        tooltip: '輸入框'
      }), _dec2 = property({
        type: Button,
        tooltip: '開始按鈕'
      }), _dec3 = property({
        type: Button,
        tooltip: '停止按鈕'
      }), _dec4 = property({
        type: _crd && RadialProgress === void 0 ? (_reportPossibleCrUseOfRadialProgress({
          error: Error()
        }), RadialProgress) : RadialProgress,
        tooltip: '進度圓'
      }), _dec5 = property({
        type: Label,
        tooltip: '進度圓'
      }), ccclass(_class = (_class2 = class Timer extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "timerEditorBox", _descriptor, this);

          _initializerDefineProperty(this, "startButton", _descriptor2, this);

          _initializerDefineProperty(this, "stopButton", _descriptor3, this);

          _initializerDefineProperty(this, "progressBar", _descriptor4, this);

          _initializerDefineProperty(this, "leftTimeLabel", _descriptor5, this);

          this.startTime = 0;
          this.seconds = 0;
        }

        onLoad() {
          this.startButton.node.on(Button.EventType.CLICK, this.onClickStartButton, this);
          this.stopButton.node.on(Button.EventType.CLICK, this.onClickStopButton, this);
        }

        start() {
          this.stop();
        }

        update() {
          if (this.isRunning) {
            const diffTime = Date.now() - this.startTime;

            if (diffTime > this.seconds * 1000) {
              this.stop();
              return;
            }

            const leftTime = this.seconds * 1000 - diffTime;
            const progress = leftTime / (this.seconds * 1000);
            this.progressBar.progress = progress;
            this.leftTimeLabel.string = `${(leftTime / 1000).toFixed(2)}秒`;
          }
        }

        get isRunning() {
          return this.startTime > 0 && this.seconds > 0;
        }

        stop() {
          this.startTime = 0;
          this.seconds = 0;
          this.progressBar.progress = 1;
          this.leftTimeLabel.string = '';
        }

        onClickStartButton() {
          if (Number.isNaN(+this.timerEditorBox.string)) {
            return;
          }

          const seconds = +this.timerEditorBox.string;

          if (seconds <= 0) {
            return;
          }

          this.seconds = +this.timerEditorBox.string;
          this.startTime = Date.now();
          this.progressBar.progress = 1;
          this.leftTimeLabel.string = `${this.seconds}秒`;
        }

        onClickStopButton() {
          this.stop();
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "timerEditorBox", [_dec], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "startButton", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "stopButton", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "progressBar", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "leftTimeLabel", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=515af8b7687ea7d774a39d9a0414cae8f793a1e9.js.map