System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, EditBox, Button, Label, Node, UITransform, CCFloat, _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _crd, ccclass, property, Marquee;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'proposal-class-properties is enabled and runs after the decorators transform.'); }

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      EditBox = _cc.EditBox;
      Button = _cc.Button;
      Label = _cc.Label;
      Node = _cc.Node;
      UITransform = _cc.UITransform;
      CCFloat = _cc.CCFloat;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "0851bve5JpJKqWwFQe+x8mG", "Marquee", undefined);

      __checkObsolete__(['_decorator', 'Component', 'EditBox', 'Button', 'Label', 'Node', 'UITransform', 'CCFloat']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("Marquee", Marquee = (_dec = property({
        type: EditBox,
        tooltip: '跑馬燈訊息列'
      }), _dec2 = property({
        type: Button,
        tooltip: '更新按鈕'
      }), _dec3 = property({
        type: Button,
        tooltip: '跳過按鈕'
      }), _dec4 = property({
        type: Label,
        tooltip: '跑馬燈訊息'
      }), _dec5 = property({
        type: Node,
        tooltip: '跑馬燈外框'
      }), _dec6 = property({
        type: CCFloat,
        tooltip: '跑馬燈滾動速度'
      }), ccclass(_class = (_class2 = class Marquee extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "editBox", _descriptor, this);

          _initializerDefineProperty(this, "updateButton", _descriptor2, this);

          _initializerDefineProperty(this, "skipButton", _descriptor3, this);

          _initializerDefineProperty(this, "message", _descriptor4, this);

          _initializerDefineProperty(this, "frame", _descriptor5, this);

          _initializerDefineProperty(this, "speed", _descriptor6, this);

          this.messages = ['123123', '456456456', '789789789789'];
          this.startPos = 0;
          this.endPos = 0;
          this.currentIndex = 0;
          this.stop = false;
        }

        onLoad() {
          this.updateButton.node.on(Button.EventType.CLICK, this.onUpdateButtonClick, this);
          this.skipButton.node.on(Button.EventType.CLICK, this.nextMessage, this);
          this.frame.on(Node.EventType.MOUSE_ENTER, () => {
            this.stop = true;
          });
          this.frame.on(Node.EventType.MOUSE_LEAVE, () => {
            this.stop = false;
          });
        }

        start() {
          this.initPosition();
          this.currentIndex = -1;
          this.nextMessage();
        }

        update(deltaTime) {
          if (this.stop) {
            return;
          }

          this.message.node.x -= deltaTime * this.speed;

          if (this.message.node.x + this.message.node.transformWidth < this.endPos) {
            this.nextMessage();
          }
        }

        onUpdateButtonClick() {
          this.messages = this.editBox.string.split('\n');
          this.currentIndex = -1;
          this.nextMessage();
        }

        initPosition() {
          const {
            width
          } = this.frame.getComponent(UITransform).contentSize;
          this.startPos = width / 2;
          this.endPos = -width / 2;
        }

        nextMessage() {
          if (this.messages.length === 0) {
            return;
          }

          this.currentIndex++;

          if (this.currentIndex >= this.messages.length) {
            this.currentIndex = 0;
          }

          this.message.string = this.messages[this.currentIndex];
          this.message.node.x = this.startPos;
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "editBox", [_dec], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "updateButton", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "skipButton", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "message", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "frame", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "speed", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return 10;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=395a76d8ad8e0624f5de9c01a45ad70fbe789485.js.map