System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, Button, ScrollView, EditBox, v3, Label, UITransform, _dec, _dec2, _dec3, _class, _class2, _descriptor, _descriptor2, _crd, ccclass, property, requireComponent, InfiniteScrollView;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'proposal-class-properties is enabled and runs after the decorators transform.'); }

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Button = _cc.Button;
      ScrollView = _cc.ScrollView;
      EditBox = _cc.EditBox;
      v3 = _cc.v3;
      Label = _cc.Label;
      UITransform = _cc.UITransform;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "b80e7Rj2mdGgLpKvPBZf56f", "InfiniteScrollView", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Button', 'PageView', 'Node', 'ScrollView', 'EditBox', 'v3', 'Label', 'UITransform']);

      ({
        ccclass,
        property,
        requireComponent
      } = _decorator);

      _export("InfiniteScrollView", InfiniteScrollView = (_dec = requireComponent(ScrollView), _dec2 = property({
        type: EditBox
      }), _dec3 = property({
        type: Button
      }), ccclass(_class = _dec(_class = (_class2 = class InfiniteScrollView extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "countEditBox", _descriptor, this);

          _initializerDefineProperty(this, "updateButton", _descriptor2, this);

          this.scrollView = null;
          this.lastViewY = Number.MIN_SAFE_INTEGER;
          this.currentCount = 0;
        }

        onLoad() {
          this.scrollView = this.getComponent(ScrollView);
          this.updateButton.node.on(Button.EventType.CLICK, () => {
            const count = +this.countEditBox.string;

            if (isNaN(count)) {
              return;
            }

            this.reset(count);
          });
        }

        start() {
          this.countEditBox.string = '10';
          this.reset(10);
        }

        update() {
          const viewHeight = this.scrollView.view.contentSize.height;
          const viewY = this.scrollView.content.position.y - viewHeight / 2;

          if (this.lastViewY === viewY) {
            return;
          }

          this.lastViewY = viewY;
          const perRowHeight = 40;
          let startItemIndex = Math.floor(viewY / perRowHeight);
          let offset = 0;

          if (startItemIndex < 0) {
            offset = -startItemIndex;
            startItemIndex = 0;
          }

          if (startItemIndex + this.scrollView.content.children.length >= this.currentCount) {
            startItemIndex -= startItemIndex + this.scrollView.content.children.length - this.currentCount;
          }

          this.scrollView.content.children.forEach((node, i) => {
            if (i + offset < 0 || offset > i) {
              return;
            }

            const index = startItemIndex + i + offset;
            console.log(index);

            if (offset > 0) {
              node.getComponentInChildren(Label).string = `${index}`;
            }

            node.setPosition(v3(0, -perRowHeight / 2 - (i + startItemIndex) * perRowHeight, 0));
          });
        }

        reset(count) {
          this.currentCount = count;
          this.lastViewY = Number.MIN_SAFE_INTEGER;
          this.scrollView.content.getComponent(UITransform).height = this.currentCount * 40;
          this.scrollView.scrollToTop(0.01);
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "countEditBox", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "updateButton", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      })), _class2)) || _class) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=0e7db32653ce874787c50733f319987dfc5f1164.js.map