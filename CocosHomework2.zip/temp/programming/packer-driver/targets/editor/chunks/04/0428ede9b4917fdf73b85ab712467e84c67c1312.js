System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, Button, _decorator, Node, UITransform, v3, _dec, _class, _crd, ccclass, Dragable;

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      Button = _cc.Button;
      _decorator = _cc._decorator;
      Node = _cc.Node;
      UITransform = _cc.UITransform;
      v3 = _cc.v3;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "2be1957+LlC64Fg/crfg0we", "Dragable", undefined);

      __checkObsolete__(['Button']);

      __checkObsolete__(['_decorator', 'Component', 'EventTouch', 'Node', 'UITransform', 'v3', 'Vec3']);

      ({
        ccclass
      } = _decorator);

      _export("Dragable", Dragable = (_dec = ccclass('Dragable'), _dec(_class = class Dragable extends Button {
        constructor(...args) {
          super(...args);
          this.beginPos = v3();
        }

        onLoad() {
          // this.node 取得組件的節點，並進行監聽
          this.node.on(Node.EventType.TOUCH_START, this.onTouchStart, this); // 點下去時

          this.node.on(Node.EventType.TOUCH_MOVE, this.onTouchMove, this); // 移動時
        }
        /*
        // 取消監聽事件，參數必須完全對應監聽事件
        this.node.off(Node.EventType.TOUCH_START, this.onTouchStart, this);
        this.node.off(Node.EventType.TOUCH_MOVE, this.onTouchMove, this);
        */


        onDestroy() {
          // 移除節點上的所有事件
          this.node.targetOff(this.node);
        }

        onTouchStart(event) {
          event.propagationStopped = true; // 停止事件冒泡

          const {
            x,
            y
          } = event.touch.getLocation(); // 紀錄點下去的時候，滑鼠坐標距離節點坐標多遠

          this.beginPos = this.node.getComponent(UITransform).convertToNodeSpaceAR(v3(x, y));
          this.node.parent.children.forEach(node => {
            node.zIndex--;
          });
          this.node.zIndex = this.node.parent.children.length;
        }

        onTouchMove(event) {
          event.propagationStopped = true;
          const {
            x,
            y
          } = event.touch.getLocation(); // 將事件坐標轉換為父節點的坐標系下

          const localPos = this.node.parent.getComponent(UITransform).convertToNodeSpaceAR(v3(x, y)); // 將坐標扣掉滑鼠跟節點的差值，避免節點的直接以滑鼠坐標對齊

          this.node.setPosition(localPos.subtract(this.beginPos));
        }

      }) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=0428ede9b4917fdf73b85ab712467e84c67c1312.js.map