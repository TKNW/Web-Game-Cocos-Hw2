declare module "cc/userland/macro" {

}
